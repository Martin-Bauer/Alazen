

function search() {
	// get the query from the search box
	var search_input = document.getElementById('search_input');
	var query_value = search_input.value;

	// remove suggestions for search completion
        hideSuggestions();

	// get the action (the url to send the search query to)
	// from the search form
	var search_form = document.getElementById('search_form');
	var action = search_form.getAttribute('action');

	// add request parameters to the action
	var url = action + "?query=" + query_value;
        // http://xyz.com/search.php?query=Johannes 
        //

	// create an XMLHttpRequest Object 
	var xmlhttp;
	if (window.XMLHttpRequest) {
	  // code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp = new XMLHttpRequest();
       } else {
	  // code for IE6, IE5
	  xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
       }
	
       // define callback for when request finishes
       // --> it's ASYNCHRONOUS
       xmlhttp.onreadystatechange=function() {
	  if (xmlhttp.readyState == 4) { // request complete
	      if (xmlhttp.status == 200) { // success
	          document.getElementById("results_container").innerHTML=xmlhttp.responseText;
	      } else {
	         alert("The search request to the server failed! Sorry.");
	      }
	  }
       }

       // fire the request
       xmlhttp.open("GET", url, true);
       xmlhttp.send();

}





	

function suggest() {
	// get the current query from the search box
	var search_input = document.getElementById('search_input');
	var query_value = search_input.value;

	// sanity check query 
	if (query_value.length < 1) return false;

        //hide suggestions
        hideSuggestions();

	// construct the url 
	var url = "suggest.php?query=" + query_value;
	
	// create an XMLHttpRequest Object 
	var xmlhttp;
	if (window.XMLHttpRequest) {
	  // code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp = new XMLHttpRequest();
       } else {
	  // code for IE6, IE5
	  xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
       }
	
       // define callback for when request finishes
       // --> it's ASYNCHRONOUS
       xmlhttp.onreadystatechange=function() {
	  if (xmlhttp.readyState == 4) { // request complete
	      if (xmlhttp.status == 200  // success
                   &&xmlhttp.responseText.length > 0 ) { 
	          document.getElementById("suggestion_container").innerHTML=xmlhttp.responseText;
	          document.getElementById("suggestion_container").style.display = 'block';
	      }
	  }
       }

       // fire the request
       xmlhttp.open("GET", url, true);
       xmlhttp.send();

}








function setSearch(new_query) {
	var search_input = document.getElementById('search_input');
	search_input.value = new_query;
        hideSuggestions();
}




function hideSuggestions() {
        document.getElementById("suggestion_container").innerHTML="";
	document.getElementById("suggestion_container").style.display = 'none';
}
