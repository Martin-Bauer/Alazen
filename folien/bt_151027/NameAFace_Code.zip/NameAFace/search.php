<?php 
	
	include "utils.php";


	// get query from request parameter 
	$query = $_REQUEST['query'];
	
	if (! $query) {
	    //echo "No query specified!";
	    exit;
	}

	// get the search index
	$index_array = load_index();


	// look up query term(s) in index 
	// and print html for each result

	if (isset( $index_array[$query] )) {
	    foreach ($index_array[$query] as $file) {
		echo '<div class="result_thumb">';
		echo '<img src="' . $file . '" height="150" title="' . $file . '" />';
		echo '</div>';
	    }
	} else {
	    echo "No matching results found";
	}


?>
