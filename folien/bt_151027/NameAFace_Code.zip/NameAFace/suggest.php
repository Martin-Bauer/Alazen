<?php

    include "utils.php"; 


    // get query from request parameter
    $query = $_REQUEST['query'];

    if (! $query) {
        exit;
    }

    // get the search index 
    $index_array = load_index();

    // look for completions in the index
    foreach ($index_array as $term => $files) {
        if (preg_match("/$query/", $term)) {
            echo '<div class="suggestion" onclick="setSearch(\'' . $term .'\');">';
            echo $term;
            echo '</div>';
        }
    }



?>
