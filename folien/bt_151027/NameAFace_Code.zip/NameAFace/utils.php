<?php

function load_index () {

	// load file names from directory 'faces' 
	// and create a simple index from the file_names 

	$files = scandir('faces');
	$index_array = array();

	foreach ($files as $file) {
	    if ($file != "." && $file != "..") {

		//echo $file . "<br />";

		$name = $file;
		$name = preg_replace("/\.jpg/", "", $name);
		$name_parts = preg_split("/_/", $name);
	
		foreach ($name_parts as $key) {
		    $index_array[$key][] = "faces/" . $file;
		    // alternative: 
		    // array_push($index_array[$key], "faces/".$file);
		}
	    }
	}

	return $index_array;

}

?>
